﻿// Copyright (C) Microsoft Corporation. All rights reserved.
//
// ----------------------------------------------------------------------------
// How to use this extension to selectively record:
//  - Attach to or launch the process that contains the image you want to selectively record. 
//    You could also load a trace file or a dump.
//  - Optional (You can manually load this extension)
//       Using commands: Run the command .scriptload <path>\SelectiveRecordingExt.js. 
//  - Determine what function you want to record.
//  - Call the extension function !ttdconfig with the following parameters:
//     * full function names (including module), comma separated
//     * <optional> Path and name of the file where to save the configuration. Quotes around
//     * this parameter are required. User must also escape their '\'. This must go last.
//     See printUsage() below for examples.
//  - The extension will save the configuration to a file in your %TEMP% directory.
//    If the creation of the file fails the configuration will be printed in the 
//    "Command" window between the <begin> and <end> markers. Copy the text into an
//    xml file.
//  - Take the configuration file and copy it to the machine where you want to record.
//  - Use TTD to launch the desired process and provide the config file with 
//    option -SelectiveRecording <path>.
// ----------------------------------------------------------------------------

"use strict";

// Example:
function exampleNotepad()
{
    var fullFunctionName = "notepad!UpdateStatusBar";
    generateSelectiveRecording(fullFunctionName);
}

// ----------------------------------------------------------------------------
// The main function to call is: 
//    generateSelectiveRecording(fullFunctionName, maxThread, periodDuration, maxRecordTime, flag, outputFile)
// Parameters:
// fullFunctionname     - Must be the full name of the function to selective record (including the 
//                        module). Note that this can be a string or a function object.
// maxThread            - The MaximumThreadsToRecordConcurrently in GlobalTimingParameters
// periodDuration       - The PeriodDurationInMilliseconds in GlobalTimingParameters
// maxRecordTime        - The MaximumRecordingTimePerPeriodInMilliseconds in GlobalTimingParameters
// flag                 - The Flag in GlobalTimingParameters
// outputFile           - Full path to the file where you want to save the configuration generated.
// ----------------------------------------------------------------------------

function initializeScript()
{
    return [
        new host.apiVersionSupport(1, 2),
        new host.functionAlias(generateSelectiveRecording, "ttdconfig")
    ];
}

function makePointOfInterest(functionSymbol, sizeOfAddress)
{
    return new PointOfInterest(functionSymbol, sizeOfAddress);
}

function makeMonitoringPoint(startInstruction, suspendPointList, returnAddressCondition)
{
    return new MonitoringPoint(startInstruction, suspendPointList, returnAddressCondition);
}

class PointOfInterest
{
    constructor(functionSymbol, sizeOfAddress)
    {
        if (typeof sizeOfAddress !== 'undefined')
        {
            this._sizeOfAddress = sizeOfAddress;
        }

        if (typeof functionSymbol === 'string')
        {
            let functionName = functionSymbol.substring(functionSymbol.indexOf("!") + 1); //logLn(functionName);
            let modName = functionSymbol.substring(0, functionSymbol.indexOf("!")); //logLn(modName);
            let functionFound = host.getModuleSymbol(modName, functionName);
            if (functionFound == null) 
            {
                throw `Failed to match a function to symbol ${functionSymbol}`;
            }
            this.functionObject = functionFound;
        }
        else if(functionSymbol != null)
        {
            this.functionObject = functionSymbol;
        }
        else
        {
            throw `No function symbol was provided`;
        }

        let moduleObj = findModuleObject(this.functionObject.address);
        if (moduleObj == null)
        {
            throw `Failed to match a module to address ${functionObject}`;
        }
        this.module = moduleObj
    }

    get rva()
    {
        if (this.functionObject.address < this.baseAddress)
        {
            throw `Incorrect function and module combination. The base\n` +
            `address of the module is greater than the function address`;
        }
        return this.functionObject.address.subtract(this.baseAddress);
    }

    get moduleName()
    {
        let name = this.module.Name;
        return name.substring(name.lastIndexOf("\\") + 1);
    }

    get timeDateStamp()
    {
        return this.module.Contents.Headers.FileHeader.TimeDateStamp;
    }

    get virtualSize()
    {
        return this.module.Size;
    }

    get baseAddress() 
    {
        return this.module.BaseAddress;
    }

    get pdbGuid() 
    {
        try
        {
            let codeInfo = this.module.Contents.DebugInfo.CodeView;
            if (codeInfo.Signature == 'RSDS') 
            {
                let guid = codeInfo.Data.Guid.toString();
                // Remove the {}
                return guid.substring(1,guid.length -1); 
            }
        }
        catch (err)
        {
            return null;
        }
    }

    get sizeOfAddress() 
    {
        return this._sizeOfAddress;
    }

    set sizeOfAddress(address) 
    {
        this._sizeOfAddress = address;
    }
}

class MonitoringPoint 
{
    constructor(startInstruction, suspendPointList, returnAddressCondition) 
    {
        this.startInstruction = startInstruction;
        this.suspendList = (typeof suspendPointList !== 'undefined') ? suspendPointList : [];
        
        if(typeof returnAddressCondition !== 'undefined')
        {
            this._returnAddressCondition = returnAddressCondition;
        }
    }

    get startingInstruction() 
    {
        return this.startInstruction;
    }

    get returnAddressCondition() 
    {
        return this._returnAddressCondition;
    }

    get suspendPointList() 
    {
        return this.suspendList; // Points of interest
    }

    convertToTtdConfig(startIndent)
    {
        var instructionExecutionEntryText =
`${startIndent}<InstructionExecutionEntry>
${startIndent}  <StartInstruction>
${startIndent}    <Address>
${startIndent}      <Rva>0x${this.startInstruction.rva.toString(16)}</Rva>
${startIndent}      <Module>
${startIndent}        <Name>${this.startInstruction.moduleName}</Name>
${startIndent}        <TimeDateStamp>0x${this.startInstruction.timeDateStamp.toString(16)}</TimeDateStamp>
${startIndent}        <VirtualSize>0x${this.startInstruction.virtualSize.toString(16)}</VirtualSize>` +
`\r\n${(this.startInstruction.pdbGuid != null) ? startIndent + "        <PdbGuid>" + this.startInstruction.pdbGuid + "</PdbGuid>" : ""}
${startIndent}      </Module>
${startIndent}    </Address>
${startIndent}  </StartInstruction>`;

        for (let suspendPoint of this.suspendList)
        {
            instructionExecutionEntryText += `
${startIndent}  <SuspendInstruction>
${startIndent}    <Address>
${startIndent}      <Rva>0x${suspendPoint.rva.toString(16)}</Rva>` +
`${(suspendPoint.sizeOfAddress != null) ? startIndent + "      <Size>0x" + suspendPoint.sizeOfAddress.toString(16) + "</Size>" : ""}
${startIndent}    </Address>
${startIndent}  </SuspendInstruction>`;
        }

        instructionExecutionEntryText += `\r\n${startIndent}</InstructionExecutionEntry>\r\n`;
        return instructionExecutionEntryText;
    }
}

class GlobalTiming
{
    constructor(timingParameters) 
    {
        this.maxThread = timingParameters.maxThread;
        this.periodDuration = timingParameters.periodDuration;
        this.maxRecordTime = timingParameters.maxRecordTime;
        this.flag = timingParameters.flag;
    }

    convertToTtdConfig(startIndent)
    {
        var globalTimingParametersText = `${startIndent}<GlobalTimingParameters>`
        if (typeof this.maxThread !== 'undefined' && this.maxThread !== null)
        {
            globalTimingParametersText += `\r\n${startIndent}  <MaximumThreadsToRecordConcurrently>${this.maxThread.toString()}</MaximumThreadsToRecordConcurrently>`;
        }
        if (typeof this.periodDuration !== 'undefined' && this.periodDuration !== null)
        {
            globalTimingParametersText += `\r\n${startIndent}  <PeriodDurationInMilliseconds>${this.periodDuration}</PeriodDurationInMilliseconds>`;
        }
        if (typeof this.maxRecordTime !== 'undefined' && this.maxRecordTime !== null)
        {
            globalTimingParametersText += `\r\n${startIndent}  <MaximumRecordingTimePerPeriodInMilliseconds>${this.maxRecordTime}</MaximumRecordingTimePerPeriodInMilliseconds>`;
        }
        if (typeof this.flag !== 'undefined' && this.flag !== null)
        {
            globalTimingParametersText += `\r\n${startIndent}  <Flag>${this.flag}</Flag>`;
        }
        else
        {
            globalTimingParametersText += `\r\n${startIndent}  <Flag>StopRecordingPreemptively</Flag>`;
        }

        globalTimingParametersText += `\r\n${startIndent}</GlobalTimingParameters>\r\n`;
        return globalTimingParametersText;
    }
}

function generateSelectiveRecording()
{
    // "arguments" is a local array-like object within all functions. It only has the
    // length property unlike regular JavaScript arrays
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/arguments#Description
    if (arguments.length == 0)
    {
        printUsage();
        return;
    }

    var configFile = null;

    var listOfFunctions = Array.from(arguments);
    if (typeof listOfFunctions[listOfFunctions.length - 1] === "string")
    {
        configFile = listOfFunctions.pop();
    }

    var configurationText = "<SelectiveRecordingConfig>\r\n";

    for (let funct of listOfFunctions)
    {
        configurationText += generateSingleMonitoringPoint(funct);
    }

    configurationText += "</SelectiveRecordingConfig>\r\n";

    try
    {
        var fileName = (configFile != null) ? configFile : getFileName();
        writeConfigToFile(fileName, configurationText);

        logLn(`Successfully created the configuration for selective recording\n` +
            `\nFile: ${fileName}\n`);
    }
    catch (err)
    {
        // Since we can't create the file print out the text
        logLn(`Failed to create the file ${fileName} with error ${err}.\n` +
            `Here is the text needed, copy it into an text file and rename it to .ttdconfig\n\n${configurationText} \n`);
    }
}

function createFunctionList()
{
    return Array.from(arguments);
}

function createConfigwithThrottle(functionList, timingParameters, configFile)
{
    var configurationText = "<SelectiveRecordingConfig>\r\n";

    for (let funct of functionList)
    {
        configurationText += generateSingleMonitoringPoint(funct);
    }

    configurationText += generateGlobalTimingParameters(timingParameters);

    configurationText += "</SelectiveRecordingConfig>\r\n";
    
    try
    {
        var fileName = (configFile != null) ? configFile : getFileName();
        writeConfigToFile(fileName, configurationText);

        logLn(`Successfully created the configuration for selective recording\n` +
            `\nFile: ${fileName}\n`);
    }
    catch (err)
    {
        // Since we can't create the file print out the text
        logLn(`Failed to create the file ${fileName} with error ${err}.\n` +
            `Here is the text needed, copy it into an text file and rename it to .ttdconfig\n\n${configurationText} \n`);
    }
}

function generateSingleMonitoringPoint(functionObject)
{
    try
    {
        let startingPoint = new PointOfInterest(functionObject);
        let monitorPoint = new MonitoringPoint(startingPoint);

        let configurationText = monitorPoint.convertToTtdConfig(" ");
        return configurationText;
    }
    catch (err)
    {
        logLn(`An error occurred during the generation of the monitoring point for function ${functionObject}.`);
        logLn(`***\n ${err} ***`);
        return "InvalidConfiguration";
    }
}

function generateGlobalTimingParameters(timingParameters)
{
    let globalTimingParameters = new GlobalTiming(timingParameters);
    try
    {
        let configurationText = globalTimingParameters.convertToTtdConfig(" ");
        return configurationText;
    }
    catch(err)
    {
        logLn(`An error occurred during the generation of the global timing parameters 
                MaximumThreadsToRecordConcurrently: ${timingParameters.maxThread} 
                PeriodDurationInMilliseconds: ${timingParameters.periodDuration} 
                MaximumRecordingTimePerPeriodInMilliseconds: ${timingParameters.maxRecordTime} 
                Flag: ${timingParameters.flag}.`);
        logLn(`***\n ${err} ***`);
        return "InvalidConfiguration";
    }
}

function findModuleObject(address)
{
    for (let moduleObj of host.currentProcess.Modules)
    {
        if (address.compareTo(moduleObj.BaseAddress) >= 0 /* address >= moduleStart */
            && address.compareTo(moduleObj.BaseAddress.add(moduleObj.Size)) < 0 /* address < moduleEnd */)
        {
            return moduleObj;
        }
    }
    // no match
    return null;
}

function getFileName()
{
    // Save the configuration
    let fileName = "selectiveConfig.ttdconfig";
    let path = host.namespace.Debugger.Utility.FileSystem.TempDirectory + "\\";
    return path + fileName;
}

function writeConfigToFile(fileName, configurationText)
{
    // TODO: Add 'CreateAlways' once Bill checks in the fix
    let fixedFileName = fileName.replace(/\\/g, '\\\\');
    let fileHandle = host.namespace.Debugger.Utility.FileSystem.CreateFile(fixedFileName);
    let writer = host.namespace.Debugger.Utility.FileSystem.CreateTextWriter(fileHandle, 'Utf8');
    writer.WriteLine(configurationText.toString());
    fileHandle.Close();
}

function printUsage()
{
    logLn("Usage: !ttdconfig(<function>[, \"<path>\\\\<file name>.ttdconfig\"])");
    logLn("       Create a selective recording configuration (.ttdconfig) file for a function.");
    logLn("Example: !ttdconfig(notepad!UpdateStatusBar, \"c:\\\\temp\\\\notepad.ttdconfig\")");
    logLn("Alternatively: !ttdconfig(notepad!UpdateStatusBar). This will create a");
    logLn("       configuration file in your %TEMP% folder.");
}


let logLn = function (s) {
    host.diagnostics.debugLog(s + '\n');
}
