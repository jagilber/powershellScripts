﻿//begin_both
//----------------------------------------------------------------------------
//
// HeapAnalysis.js - Present heap-related call data for the loaded TTD trace
//                   in the debugger data model.
//
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//end_both
//begin_internal
// Prerequisite: ttdanalyze.dll debugger extension has been loaded in the debugger
//
// This extension projects raw call data from ttdanalyze (provided by @$cursession.TTD.Calls())
// into friendlier data that is specific to Heap APIs and hides Windows implementation details.
//
// The following extensions to the datamodel are provided:
//
// dx @$cursession.TTD.Data.Heap()
// --------------------------------
// Returns an indexable list of heap API operations that change the address space in some way:
// alloc, realloc, free and a few others. It does not return heap API operations that are just
// queries (e.g. getting size of allocated block.)
//
// 0:000> dx -g @$cursession.TTD.Heap()
// ===================================================================================================================
// =           = Action   = Heap             = Address          = Size     = Flags  = (+) TimeRange         = Result =
// ===================================================================================================================
// = [0x0]     - Alloc    - 0x1a3f7430000    - 0x1a3f7459b40    - 0x208    - 0x0    - [10:EE, 12:36]        -        =
// = [0x1]     - Free     - 0x1a3f7430000    - 0x1a3f7459b40    -          - 0x0    - [12:472, 14:2B]       - 0x1    =
// = [0x2]     - Alloc    - 0x1a3f7430000    - 0x1a3f744bb90    - 0x7b     - 0x8    - [14:23A8, 16:36]      -        =
// = [0x3]     - Alloc    - 0x1a3f7430000    - 0x1a3f744bc40    - 0x46     - 0x0    - [17:79D, 19:36]       -        =
// = [0x4]     - Free     - 0x1a3f7430000    - 0x1a3f744bc40    -          - 0x0    - [1D:32, 1F:2B]        - 0x1    =
// = [0x5]     - Alloc    - 0x1a3f7430000    - 0x1a3f744bc40    - 0x10     - 0x0    - [50:167, 52:36]       -        =
// = [0x6]     - Alloc    - 0x1a3f7430000    - 0x1a3f7439ff0    - 0x38     - 0x0    - [AD:6F, AF:36]        -        =
// = [0x7]     - Alloc    - 0x1a3f7430000    - 0x1a3f744bc80    - 0x2      - 0x0    - [AF:FD, B1:36]        -        =
// = [0x8]     - Free     - 0x1a3f7430000    - 0x1a3f744bc80    -          - 0x0    - [B3:76, B5:2B]        - 0x1    =
// = [0x9]     - Alloc    - 0x1a3f7430000    - 0x1a3f744bc80    - 0x2      - 0x0    - [B5:CF, B7:36]        -        =
// ===================================================================================================================
//
// Most fields should be self explanatory. If you click on a TimeRange you will see the extent of the call:
//
// 0:000> dx @$cursession.TTD.Heap()[5]
// @$cursession.TTD.Heap()[5]                
//    Action           : Alloc
//    Heap             : 0x1a3f7430000
//    Address          : 0x1a3f744bc40
//    Size             : 0x10
//    Flags            : 0x0
//    TimeRange        : [50:167, 52:36]
// 0:000> dx -r1 @$cursession.TTD.Heap()[5].@"TimeRange"
// @$cursession.TTD.Heap()[5].@"TimeRange"                 : [50:167, 52:36]
//     MinPosition      : 50:167 [Time Travel]
//     MaxPosition      : 52:36 [Time Travel]
//
// Clicking on [Time Travel] will take you to that position in the trace.
//
// dx @$cursession.TTD.Utility.GetHeapAddress(address)
// ---------------------------------------------------
// Filters Heap() to just the entries that impact the specified address. The address can point anywhere inside a memory block, it is not required to point to
// the start of a block.
//
// Example use: Debugging a critical heap error (but see HeapAnalyze() below for the easier way...)
//
// Start by ensuring trace is indexed:
//
// 0:000> !index
// Indexed 1/1 keyframes
// Successfully created the index in 29ms.
//
// Use !events to navigate to the spot where the critical error is raised (which gives example queries to use in place of !events):
//
// 0:000> !events
// This command is not supported. You can now use the Data Model to explore events in the trace.
// Use dx to query for what you are looking for. Examples:
// - Querying for exceptions:
//    dx @$curprocess.TTD.Events.Where(t => t.Type == "Exception").Select(e => e.Exception) 
// - Querying for the load event(s) of a particular module
//    dx @$curprocess.TTD.Events.Where(t => t.Type == "ModuleLoaded").Where(t => t.Module.Name.Contains("ntdll.dll")) 
// - Querying for the threads that get created
//    dx -g @$curprocess.TTD.Events.Where(t => t.Type == "ThreadCreated").Select(t => t.Thread) 
// 
// To learn more visit https://aka.ms/ttddatamodel 
//
// Click on the first query to get the list of exceptions and click on the exception to get details:
//
// 0:000> dx @$curprocess.TTD.Events.Where(t => t.Type == "Exception").Select(e => e.Exception)
// @$curprocess.TTD.Events.Where(t => t.Type == "Exception").Select(e => e.Exception)                
//     [0x0]            : Exception of type Software at PC: 0X7FF83B92BF60
// 0:000> dx -r1 @$curprocess.TTD.Events.Where(t => t.Type == "Exception").Select(e => e.Exception)[0]
// @$curprocess.TTD.Events.Where(t => t.Type == "Exception").Select(e => e.Exception)[0]                 : Exception of type Software at PC: 0X7FF83B92BF60
//     Position         : 74:0
//     Type             : Software
//     ProgramCounter   : 0x7ff83b92bf60
//     Code             : 0xc0000374
//     Flags            : 0x1
//     RecordAddress    : 0x0
//
// 0xc0000374 is the exception code for a heap error. Travel to that position and dump the start of the stack with parameters. The 4th parameter is the
// heap address that has a problem:
//
// 0:000> !tt  74:0
// Setting position: 74:0
// (2420.4100): Break instruction exception - code 80000003 (first/second chance not available)
// Time Travel Position: 74:0
// ntdll!RtlRaiseException:
// 00007ff8`3b92bf60 4055            push    rbp
// 0:000> kP
//  # Child-SP          RetAddr           Call Site
// 00 000000b8`c811f6f8 00007ff8`3b9e166b ntdll!RtlRaiseException(
// 			struct _EXCEPTION_RECORD * ExceptionRecord = 0x000000b8`c811f750) [minkernel\ntos\rtl\amd64\raise.c @ 52] 
// 01 000000b8`c811f700 00007ff8`3b9e8b7e ntdll!RtlReportCriticalFailure(
// 			long StatusCode = 0n-1073740940, 
// 			void * FailureInfo = 0x00007ff8`3ba46700, 
// 			unsigned long BreakIfDbgPresent = 1)+0x97 [minkernel\ntos\rtl\rtlutil.c @ 202] 
// 02 000000b8`c811f810 00007ff8`3b98ce0e ntdll!RtlpHeapHandleError(
// 			long ErrorLevel = 0n-938346672)+0x12 [minkernel\ntos\rtl\heaplog.c @ 374] 
// 03 000000b8`c811f840 00007ff8`3b99e2ab ntdll!RtlpLogHeapFailure(
// 			_HEAP_FAILURE_TYPE FailureType = 0n-938346672 (No matching enumerant), 
// 			void * HeapAddress = 0x00000235`79330000, 
// 			void * Address = 0x00000235`7942f850, 
// 			void * Param1 = 0x00000235`7942f860, 
// 			void * Param2 = 0x00000000`00000000, 
// 			void * Param3 = 0x00000000`00000000)+0x96 [minkernel\ntos\rtl\heaplog.c @ 714] 
//
// Ask TTD to locate all of the operations that impacted the address:
//
// 0:000> dx -g @$cursession.TTD.Utility.GetHeapAddress(0x00000235`7942f860)
// =====================================================================================================================
// =          = Action   = Heap             = Address          = Size    = Flags  = (+) TimeRange      = Result        =
// =====================================================================================================================
// = [0x0]    - Alloc    - 0x23579330000    - 0x2357942f860    - 0x32    - 0x0    - [59:12, 5B:36]     -               =
// = [0x1]    - Free     - 0x23579330000    - 0x2357942f860    -         - 0x0    - [63:13, 65:2B]     - 0x1           =
// = [0x2]    - Free     - 0x23579330000    - 0x2357942f860    -         - 0x0    - [6D:13, 6D:B13]    - 0x6917108b    =
// =====================================================================================================================
//
// From this it is easy to see that the problem is a double free. The time positions for both the first and second free can be navigated to in order to understand the root cause.
//
// !ttdanalyze
// -----------------------------------------
// .GetHeapAddress() is a useful generic function but that was alot of manual steps with specific domain knowledge to get the answer.
// As a demonstration of checkers, HeapAnalyze() automates the above analysis. Simply run HeapAnalyze() and it will determine if a 
// heap error is in the trace and display the relevant heap operation information:

// 0:000> !ttdanalyze
// Heap failure detected!
//     error: heap_failure_block_not_busy
//      heap: 0x23579330000
//   address: 0x2357942f860
// =====================================================================================================================
// =          = Action   = Heap             = Address          = Size    = Flags  = (+) TimeRange      = Result        =
// =====================================================================================================================
// = [0x0]    - Alloc    - 0x23579330000    - 0x2357942f860    - 0x32    - 0x0    - [59:12, 5B:36]     -               =
// = [0x1]    - Free     - 0x23579330000    - 0x2357942f860    -         - 0x0    - [63:13, 65:2B]     - 0x1           =
// = [0x2]    - Free     - 0x23579330000    - 0x2357942f860    -         - 0x0    - [6D:13, 6D:B13]    - 0x6917108b    =
// =====================================================================================================================
//end_internal
//begin_both
//----------------------------------------------------------------------------

"use strict";

class ttdData
{
    // Return call information for all heap operations that can create/move/destroy memory
    // By default Heap() [or Heap(true)] filters out internal calls as they are generally not interesting to client code. 
    // To see all the allocations, such as LFH blocks which are subdivided before being returned to clients, call Heap(false).

    get [Symbol.metadataDescriptor]()
    {
        return {
            Heap : { PreferShow : true, Help : "Returns normalized heap information from the time travel trace (such as memory allocation, reallocation or frees)" }
        }
    }

    Heap(ignoreInternalAllocations)
    {
        // Public heap flags
        var HEAP_NO_SERIALIZE           = 0x00000001;
        var HEAP_GENERATE_EXCEPTIONS    = 0x00000004;
        var HEAP_ZERO_MEMORY            = 0x00000008;
        var HEAP_REALLOC_IN_PLACE_ONLY  = 0x00000010;
        var HEAP_CREATE_ENABLE_EXECUTE  = 0x00040000;

        var PUBLIC_HEAP_FLAGS =
            HEAP_NO_SERIALIZE
            | HEAP_GENERATE_EXCEPTIONS
            | HEAP_ZERO_MEMORY
            | HEAP_REALLOC_IN_PLACE_ONLY
            | HEAP_CREATE_ENABLE_EXECUTE
            ;
        var PRIVATE_HEAP_FLAGS = ~PUBLIC_HEAP_FLAGS;

        var exemptedFlagMask = (ignoreInternalAllocations === false) ? 0 : PRIVATE_HEAP_FLAGS;

        var heapCalls = this.capturedSession().TTD.Calls(
            "ntdll!RtlAllocateHeap",
            "ntdll!RtlCreateHeap",
            "ntdll!RtlDestroyHeap",
            "ntdll!RtlFreeHeap",
            "ntdll!RtlLockHeap",
            "ntdll!RtlProtectHeap",
            "ntdll!RtlReAllocateHeap",
            "ntdll!RtlUnlockHeap"
            );

        return heapCalls.Select(function(c)
            {
                switch (c.Function)
                {

                    // PVOID RtlAllocateHeap ( __in PVOID HeapHandle, __in_opt ULONG Flags, __in SIZE_T Size )
                    case "ntdll!RtlAllocateHeap":
                        return {
                            "Action"     : "Alloc",
                            "Heap"       : c.RawParameters[0],
                            "Address"    : c.RawReturnValue,
                            "Size"       : c.RawParameters[2],
                            "Flags"      : c.RawParameters[1],
                            "TimeStart"  : c.TimeStart,
                            "TimeEnd"    : c.TimeEnd
                        };

                    // PVOID RtlReAllocateHeap ( __in PVOID HeapHandle, __in ULONG Flags, __in PVOID BaseAddress, __in SIZE_T Size )
                    case "ntdll!RtlReAllocateHeap":
                        return {
                            "Action"            : "ReAlloc",
                            "Heap"              : c.RawParameters[0],
                            "Address"           : c.RawReturnValue,
                            "PreviousAddress"   : c.RawParameters[2],
                            "Size"              : c.RawParameters[3],
                            "Flags"             : c.RawParameters[1],
                            "TimeStart"         : c.TimeStart,
                            "TimeEnd"           : c.TimeEnd
                        };

                    // LOGICAL RtlFreeHeap ( __in PVOID HeapHandle, __in_opt ULONG Flags, __in __post_invalid  PVOID BaseAddress )
                    case "ntdll!RtlFreeHeap":
                        return {
                            "Action"     : "Free",
                            "Heap"       : c.RawParameters[0],
                            "Address"    : c.RawParameters[2],
                            "Flags"      : c.RawParameters[1],
                            "Result"     : c.RawReturnValue,
                            "TimeStart"  : c.TimeStart,
                            "TimeEnd"    : c.TimeEnd
                        };

                    // PVOID RtlCreateHeap ( __in ULONG Flags, __in_opt PVOID HeapBase, __in_opt SIZE_T ReserveSize, __in_opt SIZE_T CommitSize # not recorded yet (> 4 parameters): , __in_opt PVOID Lock, __in_opt PRTL_HEAP_PARAMETERS Parameters )
                    case "ntdll!RtlCreateHeap":
                        return {
                            "Action"     : "Create",
                            "Heap"       : c.RawReturnValue,
                            "BaseAddress": c.RawParameters[1],
                            "Flags"      : c.RawParameters[0],
                            "ReserveSize": c.RawParameters[2],
                            "CommitSize" : c.RawParameters[3],
                            "TimeStart"  : c.TimeStart,
                            "TimeEnd"    : c.TimeEnd
                        };

                    // VOID NTAPI RtlProtectHeap ( _In_ PVOID HeapHandle, _In_ BOOLEAN MakeReadOnly );
                    case "ntdll!RtlProtectHeap":
                        return {
                            "Action"        : "Protect",
                            "Heap"          : c.RawParameters[0],
                            "MakeReadOnly"  : c.RawParameters[1],
                            "TimeStart"     : c.TimeStart,
                            "TimeEnd"       : c.TimeEnd
                        };

                    // BOOLEAN RtlLockHeap ( _In_ PVOID HeapHandle )
                    case "ntdll!RtlLockHeap":
                        return {
                            "Action"     : "Lock",
                            "Heap"       : c.RawParameters[0],
                            "Result"     : c.RawReturnValue,
                            "TimeStart"  : c.TimeStart,
                            "TimeEnd"    : c.TimeEnd
                        };

                    // BOOLEAN RtlUnlockHeap ( _In_ PVOID HeapHandle )
                    case "ntdll!RtlUnlockHeap":
                        return {
                            "Action"     : "Unlock",
                            "Heap"       : c.RawParameters[0],
                            "Result"     : c.RawReturnValue,
                            "TimeStart"  : c.TimeStart,
                            "TimeEnd"    : c.TimeEnd
                        };

                    // PVOID RtlDestroyHeap ( __in __post_invalid PVOID HeapHandle )
                    case "ntdll!RtlDestroyHeap":
                        return {
                            "Action"     : "Destroy",
                            "Heap"       : c.RawParameters[0],
                            "Result"     : c.RawReturnValue,
                            "TimeStart"  : c.TimeStart,
                            "TimeEnd"    : c.TimeEnd
                        };

                    default:
                        return c;
                }
            }).Where(function(c)
            {
                return (c.Flags === undefined) || ((c.Flags & exemptedFlagMask) == 0);
            });
    }
}

class ttdUtility
{
    get [Symbol.metadataDescriptor]()
    {
        return {
            GetHeapAddress : { PreferShow : true, Help : "Returns all the heap operations that impact the specified address" }
        }
    }

    // Return all the create/move/destroy heap operations that impact specified address
    GetHeapAddress(address)
    {
        return this.capturedSession().TTD.Data.Heap().Where(function(c)
        {
            // compare address to range (free blocks do not have a size so make min size of 1)
            return address >= c.Address && address < (c.Address + (c.Size ? c.Size : 1));
        });
    }
}

//end_both
//begin_internal

class ttdAnalyzers
{
    // Check to see if there was a heap error in the trace
    Analyze_HeapAnalysis_HeapException()
    {
        host.diagnostics.debugLog("checking for heap errors\n");

        // See if the heap error routine was ever called
        // Parameter1 is the error enum
        // Parameter2 is the heap handle
        // Parameter3 is the heap block address (not the user heap address) that failed
        var heapError = this.capturedSession().TTD.Calls("ntdll!RtlpLogHeapFailure");
        if (heapError === undefined || heapError.Count() == 0)
        {
            return;
        }
        heapError = heapError.First();

        // RtlpLogHeapFailure reports the heap block's header address, not the address
        // which is returned to the caller of RtlAllocateHeap. In order to locate all
        // the heap activity we need to map the failure call to a user heap address.
        // This mapping is done by finding the heap operation whose time range intersects
        // the time of the failure and then pulling the heap address from the intersecting
        // operation.
        var heapOperation = this.capturedSession().TTD.Data.Heap().Where(function(c)
        {
            return heapError.TimeRange.MinPosition.compareTo(c.TimeRange.MinPosition) >= 0
                && heapError.TimeRange.MinPosition.compareTo(c.TimeRange.MaxPosition) <= 0;
        }).First();

        // Print information about the heap failure
        var HEAP_FAILURE_TYPE =
        [
            "heap_failure_internal",
            "heap_failure_unknown",
            "heap_failure_generic",
            "heap_failure_entry_corruption",
            "heap_failure_multiple_entries_corruption",
            "heap_failure_virtual_block_corruption",
            "heap_failure_buffer_overrun",
            "heap_failure_buffer_underrun",
            "heap_failure_block_not_busy",
            "heap_failure_invalid_argument",
            "heap_failure_usage_after_free",
            "heap_failure_cross_heap_operation",
            "heap_failure_freelists_corruption",
            "heap_failure_listentry_corruption",
            "heap_failure_lfh_bitmap_mismatch"
        ];

        var failureReason = 0 + heapError.Parameter1;
        host.diagnostics.debugLog("Heap failure detected!\n");
        host.diagnostics.debugLog("    error: " + HEAP_FAILURE_TYPE[failureReason] + "(" + failureReason + ")\n");
        host.diagnostics.debugLog("     heap: " + heapError.RawParameters[1].toString(16) + "\n");
        host.diagnostics.debugLog("  address: " + heapOperation.Address.toString(16) + "\n");

        // Report all the activity for the heap Address
        return {
            HeapErrors : this.capturedSession().TTD.Utility.GetHeapAddress(heapOperation.Address)
        }
    }
}

//end_internal
//begin_both

function initializeScript()
{
    return [
        new host.apiVersionSupport(1, 2),
        new host.namedModelParent     (ttdData, "TTDAnalyze.Data"),
        new host.namedModelParent  (ttdUtility, "TTDAnalyze.Utility"),
//end_both        
//begin_internal
        new host.namedModelParent(ttdAnalyzers, "TTDAnalyze.Analyzers")
//end_internal
//begin_both        
    ];
}

//end_both
