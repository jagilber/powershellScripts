﻿"use strict";

var __sessionBookmarkDictionary = {};
var __currentUniqueID = 0;

class SessionBookmarks
{
    get Bookmarks()
    {
        var file = this.Attributes.Target.Details.DumpFileName;
        if (!(file in __sessionBookmarkDictionary))
        {
            __sessionBookmarkDictionary[file] = new BookmarkCollection;
        }
        
        return __sessionBookmarkDictionary[file];
    }
}

class Bookmark
{
    constructor(collection, name, category, timestamp)
    {
        if (timestamp.Sequence === undefined || timestamp.Steps === undefined)
        {
            throw "Bookmark must be added at a valid timestamp";
        }
        this.__collection = collection;
        this.__name = name;
        this.__category = category;
        this.__timestamp = timestamp;
        this.UniqueID = __currentUniqueID++;
    }

    get Name()
    {
        return this.__name;
    }

    set Name(value)
    {
        this.__name = value;
    }

    get Timestamp()
    {
        return this.__timestamp;
    }

    set Timestamp(value)
    {
        this.__timestamp = value;
    }

    get Category()
    {
        return this.__category;
    }

    set Category(value)
    {
        this.__category = value;
    }

    Remove()
    {
        this.__collection.__Remove(this);
    }

    toString()
    {
        if (this.Name === undefined)
        {
            return "Bookmark: " + this.__timestamp.toString();
        }
        return "Bookmark: " + this.Name;
    }
}

class BookmarkCollection
{
    constructor()
    {
        this.__bookmarks = [];
    }
    
    AddBookmark(name, category, timestamp)
    {
        if (timestamp === undefined)
        {
            // We could add a bookmark from the wrong session if the current thread doesn't belong to this session.
            // You'd have to jump through hoops to get to there, so I'll leave that as a problem for later
            timestamp = host.currentThread.TTD.Position;
        }
        if (category === undefined)
        {
            category = "bookmark";
        }
        // It's ok for name to be undefined, we'll just use the timestamp for a display string
        this.__bookmarks.push(new Bookmark(this, name, category, timestamp));
    }

    DeleteBookmarkByID(id)
    {
        this.__bookmarks = this.__bookmarks.filter(b => b.UniqueID !== id);
    }

    __Remove(bookmark)
    {
        for( var i = 0; i < this.__bookmarks.length; i++)
        {
            if (this.__bookmarks[i] === bookmark)
            {
                this.__bookmarks.splice(i, 1);
                return;
            }
        }
    }

    *[Symbol.iterator]()
    {
        yield* this.__bookmarks;
    }

    SaveAsJson()
    {
        var serialBookmarks = this.__bookmarks.map(
            x => 
            {
                return {
                    Name: x.Name,
                    Category: x.Category,
                    Sequence: x.Timestamp.Sequence.asNumber(),
                    Steps: x.Timestamp.Steps.asNumber()
                };
            }
        )
        return JSON.stringify(serialBookmarks);
    }

    LoadFromJson(jsonBookmarks)
    {
        var create = host.namespace.Debugger.Utility.Objects.CreateInstance;
        var serialBookmarks = JSON.parse(jsonBookmarks);
        this.__bookmarks = serialBookmarks.map(
            x => new Bookmark(this, x.Name, x.Category, create("Debugger.Models.TTD.Position", x.Sequence, x.Steps))
        )
    }

    toString()
    {
        return "Bookmark collection";
    }
}

function initializeScript()
{
    return [new host.namespacePropertyParent(SessionBookmarks, "Debugger.Models.Session", "TTDAnalyze", "TTD"),
            new host.apiVersionSupport(1, 3)];
}
