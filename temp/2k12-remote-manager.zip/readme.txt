﻿extract this zip to c:\temp so that the structure looks exactly as below
from admin powershell prompt in c:\temp

to start:
.\remote-manager.ps1 -import .\httpsf.json -start -debugScript
or
.\remote-manager.ps1 -import .\httpsf.json -start -debugScript -machines 10.0.0.4,10.0.0.5

to stop:
.\remote-manager.ps1 -import .\httpsf.json -stop -debugScript
or
.\remote-manager.ps1 -import .\httpsf.json -stop -debugScript -machines 10.0.0.4,10.0.0.5


extracted zip file structure:
C:\TEMP\2K12-REMOTE-MANAGER
|   gateway.json
|   httpsf.json
|   remote-manager.ps1
|   
+---2k12-rds-tracing
|       logman-wrapper.ps1
|       single-session.xml
|       
+---events-export
|       event-log-manager.ps1
|       log-merge.ps1
|       
+---gather
|   \---2018-12-06-02-51-51
|       \---nt0000000
|               logman-Wrapper.log
|               logman-wrapper.ps1
|               PerfLog-Long_12060251.blg
|               PerfLog-Short_12060251.blg
|               perfmon.mgr.bat
|               processList.txt
|               readme.txt
|               single-session.etl
|               single-session.xml
|               
+---perfmon
|       perfmon.mgr.bat
|       
\---xperf
        wpr.mgr.bat
        xperf.mgr.bat




after successful start and stop, gather folder should be created and output should look similar to below
PS C:\temp> tree /a /f .\2k12-remote-manager
C:\TEMP\2K12-REMOTE-MANAGER
+---gather
|   \---2018-12-06-02-51-51
|       \---nt0000000
|               logman-Wrapper.log
|               logman-wrapper.ps1
|               PerfLog-Long_12060251.blg
|               PerfLog-Short_12060251.blg
|               perfmon.mgr.bat
|               processList.txt
|               readme.txt
|               single-session.etl
|               single-session.xml
