<#
.SYNOPSIS
  Verifies the portable TTD.exe package on a server: file hashes, Authenticode signatures, and TTD.exe startup.
.NOTES
  Run from an elevated PowerShell. Exit code 0 = all checks passed.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$failed = $false

Write-Host "TTD package root: $root"

# 1. Hash manifest
$manifest = Join-Path $root 'MANIFEST.sha256'
if (-not (Test-Path $manifest)) { Write-Host 'MANIFEST.sha256 missing' -ForegroundColor Red; exit 2 }
Write-Host "`n[1/3] File hashes"
foreach ($line in Get-Content $manifest) {
    if ($line -notmatch '^(?<hash>[0-9A-Fa-f]{64})\s+(?<path>.+)$') { continue }
    $path = Join-Path $root $Matches.path
    if (-not (Test-Path $path)) { Write-Host "  MISSING  $($Matches.path)" -ForegroundColor Red; $failed = $true; continue }
    $actual = (Get-FileHash -Algorithm SHA256 $path).Hash
    if ($actual -ieq $Matches.hash) { Write-Host "  OK       $($Matches.path)" }
    else { Write-Host "  MISMATCH $($Matches.path)" -ForegroundColor Red; $failed = $true }
}

# 2. Authenticode
Write-Host "`n[2/3] Authenticode signatures"
Get-ChildItem $root -Recurse -File -Include *.exe, *.dll, *.sys | ForEach-Object {
    $sig = Get-AuthenticodeSignature $_.FullName
    $rel = $_.FullName.Substring($root.Length + 1)
    $signer = if ($sig.SignerCertificate) { ($sig.SignerCertificate.Subject -split ',')[0] } else { '(none)' }
    if ($sig.Status -eq 'Valid' -and $signer -match 'Microsoft') { Write-Host "  OK       $rel  [$signer]" }
    else { Write-Host "  $($sig.Status.ToString().ToUpper())  $rel  [$signer]" -ForegroundColor Red; $failed = $true }
}

# 3. Startup
Write-Host "`n[3/3] TTD.exe -help"
$exe = Join-Path $root 'TTD.exe'
$ver = (Get-Item $exe).VersionInfo.FileVersion
Write-Host "  FileVersion: $ver"
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Host '  WARNING: not elevated. Recording requires an elevated prompt.' -ForegroundColor Yellow }
try {
    $out = & $exe -help 2>&1
    $rc = $LASTEXITCODE
    $head = ($out | Select-Object -First 3) -join ' | '
    Write-Host "  exit=$rc  $head"
    $text = ($out | ForEach-Object { "$_" }) -join "`n"
    if ($rc -ne 0 -or $text -notmatch 'Microsoft \(R\) TTD') { Write-Host '  Unexpected -help output' -ForegroundColor Red; $failed = $true }
} catch {
    Write-Host "  FAILED to start TTD.exe: $($_.Exception.Message)" -ForegroundColor Red; $failed = $true
}

Write-Host ''
if ($failed) { Write-Host 'RESULT: FAILED - do not use this package.' -ForegroundColor Red; exit 1 }
Write-Host 'RESULT: OK - package verified.' -ForegroundColor Green
exit 0
