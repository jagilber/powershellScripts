TTD.exe portable recorder (x64) - Microsoft Time Travel Debugging 1.11.611.0
=============================================================================

Source : https://aka.ms/ttd/download  (TTD.msixbundle, TTD-x64.msix)
Method : "Download and install the TTD.exe command line utility (offline method)"
         https://learn.microsoft.com/windows-hardware/drivers/debuggercmds/time-travel-debugging-ttd-exe-command-line-util
Built  : 2026-10-19
Supports: Windows Server 2016 / 2019 / 2022 / 2025 (x64). Records 64-bit and 32-bit processes.
No install, no App Installer, no WinDbg needed on the server.

DEPLOY
------
1. Copy ttd.zip to the server and extract to C:\Tools\TTD (any path is fine; keep the layout,
   including the x86 subfolder).
2. Open an elevated PowerShell and run:

      C:\Tools\TTD\Verify-Ttd.ps1

   This checks every file hash against MANIFEST.sha256, checks the Authenticode signatures,
   and runs TTD.exe -help. Stop if anything reports Invalid/Mismatch.
3. Accept the EULA once (interactive):  C:\Tools\TTD\TTD.exe -help
   For unattended use add -accepteula to every command after you have reviewed the EULA.

USAGE (elevated prompt; output directory must already exist)
-----------------------------------------------------------
  Launch : TTD.exe -out C:\traces -noUI -accepteula notepad.exe
  Attach : TTD.exe -out C:\traces\trace.run -noUI -accepteula -attach <PID>
  Monitor: TTD.exe -out C:\traces -noUI -accepteula -monitor <exe name>   (Ctrl+C to stop)
  Stop   : TTD.exe -stop <PID|name|all>
  Limit  : add -ring -maxFile <MB>  to cap trace size; -module <dll> to record one module only.

NOTES
-----
- Recording is 5x-20x slower for the target and the trace grows fast. Record briefly.
- Once attached, TTD cannot detach: end the recorded process to finalize the .run file.
- Send both the .run and .out files. The .idx file is not needed.
- Traces capture memory and may contain PII.
- "-monitor" installs the ProcLaunchMon.sys driver; run  TTD.exe -cleanup  afterwards to remove it.

FILES
-----
  TTD.exe, TTDInject.exe, TTDLoader.dll, TTDRecord.dll, TTDRecordCPU.dll, TTDRecordUI.dll,
  TTDLiveRecorder.dll, TTDReplay.dll, TTDReplayCPU.dll, ProcLaunchMon.sys
  x86\  (32-bit injection support; delete if you never record 32-bit processes)
  MANIFEST.sha256, Verify-Ttd.ps1, README.txt
