"use strict";

//**************************************************************************
// LinuxKernel.js:
//
// Extension for Linux Kernel debugging.  This extension is intended to provide the functionality
// of the most commonly used commands within the Linux crash utility for understanding kernel
// mode crashes.
//

delete Object.prototype.toString;
var __kernelInfo = null;

//**************************************************************************
// Utility:
//

// ListTraversal
//
// Iterates elements of a kernel list.
//
class __ListTraversal
{
    constructor(listHead, instTyName, instFldName)
    {
        this.__listHead = listHead;
        this.__instTyName = instTyName;
        this.__instTy = host.getModuleType("vmlinux", instTyName);
        this.__instFldName = instFldName;
        this.__instFld = this.__instTy.fields[instFldName];
        this.__instFldOffset = this.__instFld.offset;
    }

    *[Symbol.iterator]()
    {
        var ptr = this.__listHead.next;
        var startPtr = ptr;
        var returnedFirst = false;

        while(!ptr.isNull)
        {
            if (returnedFirst)
            {
                if (ptr.address.compareTo(startPtr.address) == 0 ||
                    ptr.address.compareTo(this.__listHead.address) == 0)
                {
                    break;
                }
            }

            yield host.createTypedObject(ptr.address.subtract(this.__instFldOffset), this.__instTy);

            ptr = ptr.next;
            returnedFirst = true;
        }
    }
}

// KListTraversal:
//
// Iterates elements of a kernel KLIST
//
class __KListTraversal
{
    constructor(klist, instTyName, instFldName)
    {
        this.__klist = klist;
        this.__klistInfo = __getKernelInfo().klistInfo;
        this.__instTyName = instTyName;
        this.__instTy = host.getModuleType("vmlinux", instTyName);
        this.__instFldName = instFldName;
        this.__instFld = this.__instTy.fields[instFldName];
        this.__instFldOffset = this.__instFld.offset;
    }

    *[Symbol.iterator]()
    {
        var ptr = this.__klist.k_list.next;
        var startPtr = ptr;
        var returnedFirst = false;

        while(!ptr.isNull)
        {
            if (returnedFirst)
            {
                if (ptr.address.compareTo(startPtr.address) == 0 ||
                    ptr.address.compareTo(this.__klist.k_list.address) == 0)
                {
                    break;
                }
            }

            yield host.createTypedObject(ptr.address.subtract(this.__instFldOffset + this.__klistInfo.klistOfNodeOffset), this.__instTy);

            ptr = ptr.next;
            returnedFirst = true;
        }
    }
}

// RbTraversal
//
// Iterates elements of a kernel red-black tree given by rb_node
//
class __RbTraversal
{
    constructor(rootRb, instTyName, instFldName)
    {
        this.__rootRb = rootRb;
        this.__instTyName = instTyName;
        this.__instTy = host.getModuleType("vmlinux", instTyName);
        this.__instFldName = instFldName;
        this.__instFld = this.__instTy.fields[instFldName];
        this.__instFldOffset = this.__instFld.offset;
    }

    *[Symbol.iterator]()
    {
        var srch = [];
        var cur = this.__rootRb;
        var lptr = this.__rootRb.rb_left;
        if (!lptr.isNull)
        {
            srch.push(lptr);
        }
        var rptr = this.__rootRb.rb_right;
        if (!rptr.isNull)
        {
            srch.push(rptr);
        }

        while(srch.length > 0)
        {
            var curRbPtr = srch.shift();
            yield host.createTypedObject(curRbPtr.address.subtract(this.__instFldOffset), this.__instTy);

            var curRb = curRbPtr.dereference();
            lptr = curRb.rb_left;
            if (!lptr.isNull)
            {
                srch.push(lptr);
            }
            rptr = curRb.rb_right;
            if (!rptr.isNull)
            {
                srch.push(rptr);
            }
        }
    }
}

function __pathCombine(p1, p2)
{
    if (p1.endsWith("/") && p2.startsWith("/"))
    {
        return p1 + p2.slice(1);
    }
    else if (p1.endsWith("/") || p2.startsWith("/"))
    {
        return p1 + p2;
    }
    else
    {
        return p1 + "/" + p2;
    }
}

//**************************************************************************
// Extension:
//

// KernelInfo:
//
// Represents kernel information that we cache within this script
//
class __KernelInfo
{
    constructor(session)
    {
        this.__session = session;
        this.__printkLogInfo = null;
        this.__namespaceInfo = null;
        this.__fileSystemInfo = null;
        this.__deviceInfo = null;
        this.__kernFsInfo = null;
        this.__klistInfo = null;
    }

    get printKLogInfo()
    {
        if (this.__printkLogInfo == null)
        {
            //
            // @TODO: host.getModuleSymbol() is still a tad slow on kernel symbols...
            //
            var printkLogType = host.getModuleType("vmlinux", "printk_log");
            var printkLogSize = printkLogType.size;
            var logBuf = host.getModuleSymbol("vmlinux", "log_buf");
            var logBufAddr = logBuf.address;
            var logSize = host.getModuleSymbol("vmlinux", "log_buf_size");
            var firstIdx = host.getModuleSymbol("vmlinux", "log_first_idx");
            var nextIdx = host.getModuleSymbol("vmlinux", "log_next_idx");

            this.__printkLogInfo =
            {
                printkLogType: printkLogType,
                printkLogSize: printkLogSize,
                logBuf: logBuf,
                logBufAddr: logBufAddr,
                logSize: logSize,
                firstIdx: firstIdx,
                nextIdx: nextIdx
            };
        }
        return this.__printkLogInfo;
    }

    get namespaceInfo()
    {
        if (this.__namespaceInfo == null)
        {
            //
            // @TODO: host.getModuleSymbol() is still a tad slow on kernel symbols...
            //
            var netNamespaceList = host.getModuleSymbol("vmlinux", "net_namespace_list");

            this.__namespaceInfo =
            {
                netNamespaceList: netNamespaceList
            };
        }
        return this.__namespaceInfo;
    }

    get fileSystemInfo()
    {
        if (this.__fileSystemInfo == null)
        {
            //
            // @TODO: host.getModuleSymbol() is still a tad slow on kernel symbols...
            //
            var superBlockList = host.getModuleSymbol("vmlinux", "super_blocks");

            this.__fileSystemInfo =
            {
                superBlockList: superBlockList
            };
        }
        return this.__fileSystemInfo;
    }

    get deviceInfo()
    {
        if (this.__deviceInfo == null)
        {
            //
            // @TODO: host.getModuleSymbol() is still a tad slow on kernel symbols...
            //
            var blockDevicesList = host.getModuleSymbol("vmlinux", "all_bdevs");

            var majorNames = host.getModuleSymbol("vmlinux", "major_names");
            var majorNamesTy = majorNames.targetType;
            var majorNamesEntryTy = majorNamesTy.baseType;
            var majorNamesCount = majorNamesTy.size / majorNamesEntryTy.size;

            var characterDevicesList = host.getModuleSymbol("vmlinux", "chrdevs");
            var characterDevicesTy = characterDevicesList.targetType;
            var characterDevicesEntryTy = characterDevicesTy.baseType;
            var characterDevicesCount = characterDevicesTy.size / characterDevicesEntryTy.size;

            this.__deviceInfo =
            {
                blockDevicesList: blockDevicesList,
                majorNames: majorNames,
                majorNamesCount: majorNamesCount,
                characterDevicesList: characterDevicesList,
                characterDevicesCount: characterDevicesCount
            };
        }
        return this.__deviceInfo;
    }

    get klistInfo()
    {
        if (this.__klistInfo == null)
        {
            var klistNodeType = host.getModuleType("vmlinux", "klist_node");
            var klistOfNodeOffset = klistNodeType.fields["n_node"].offset;

            this.__klistInfo = 
            {
                klistNodeType: klistNodeType,
                klistOfNodeOffset: klistOfNodeOffset
            };
        }
        return this.__klistInfo;
    }

    get kernFsInfo()
    {
        if (this.__kernFsInfo == null)
        {
            //
            // @TODO: host.getModuleSymbol() is still a tad slow on kernel symbols.
            //
            var systemKSet = host.getModuleSymbol("vmlinux", "system_kset");
            var node = systemKSet.kobj.sd.dereference();
            var parent = node.parent;
            while (!parent.isNull)
            {
                node = parent.dereference();
                parent = node.parent;
            }
            var subSysPrivateType = host.getModuleType("vmlinux", "subsys_private");
            var ksetType = host.getModuleType("vmlinux", "kset");
            var subSysOffset = subSysPrivateType.fields["subsys"].offset;
            var kobjOffset = ksetType.fields["kobj"].offset;

            var devicePrivateType = host.getModuleType("vmlinux", "device_private");


            this.__kernFsInfo =
            {
                root: node,
                subSysPrivateType: subSysPrivateType,
                devicePrivateType: devicePrivateType,
                ksetType: ksetType,
                subSysOffset: subSysOffset,
                kobjOffset: kobjOffset,
            }
        }
        return this.__kernFsInfo;
    }

    get perCpuInfo()
    {
        if (this.__perCpuInfo == null)
        {
            var perCpuStart = host.getModuleSymbolAddress("vmlinux", "__per_cpu_start");
            var perCpuEnd = host.getModuleSymbolAddress("vmlinux", "__per_cpu_end");
            var perCpuOffset = host.getModuleSymbol("vmlinux", "__per_cpu_offset");

            var ty = perCpuOffset.targetType;
            var baseTy = ty.baseType;
            var perCpuOffsetSize = ty.size / baseTy.size;
                 
            this.__perCpuInfo =
            {
                perCpuStart: perCpuStart,
                perCpuEnd: perCpuEnd,
                perCpuOffset: perCpuOffset,
                perCpuOffsetSize: perCpuOffsetSize
            }
        }
        return this.__perCpuInfo;
    }

    get timerInfo()
    {
        if (this.__timerInfo == null)
        {
            var jiffies = host.getModuleSymbol("vmlinux", "jiffies_64");
            var timerBases = host.getModuleSymbol("vmlinux", "timer_bases");
            var timerListType = host.getModuleType("vmlinux", "timer_list");
            var entryField = timerListType.fields["entry"];
            var entryOffset = entryField.offset;
            var hrtimerBases = host.getModuleSymbol("vmlinux", "hrtimer_bases");
            var hrtimerType = host.getModuleType("vmlinux", "hrtimer");
            var nodeField = hrtimerType.fields["node"];
            var nodeOffset = nodeField.offset;

            this.__timerInfo =
            {
                jiffies: jiffies,
                timerBases: timerBases,
                timerListType: timerListType,
                entryOffset: entryOffset,
                hrtimerBases: hrtimerBases,
                hrtimerType: hrtimerType,
                nodeOffset: nodeOffset
            }

        }
        return this.__timerInfo;
    }
}

function __getKernelInfo()
{
    if (__kernelInfo == null)
    {
        __kernelInfo = new __KernelInfo(host.currentSession);
    }
    return __kernelInfo;
}

// KernelLog:
//
// An abstraction over the printk log in the Linux kernel.
//
class __KernelLog
{
    constructor(session)
    {
        this.__session = session;
        this.__initialized = false;
    }

    __init()
    {
        if (!this.__initialized)
        {
            this.__logInfo = __getKernelInfo().printKLogInfo;
        }
        this.__initialized = true;
    }

    *[Symbol.iterator]()
    {
        this.__init();

        var curIdx = this.__logInfo.firstIdx;
        while (curIdx < this.__logInfo.nextIdx)
        {
            var entryAddr = this.__logInfo.logBufAddr.add(curIdx);
            var pkEntry = host.createTypedObject(entryAddr, this.__logInfo.printkLogType);
            var ns = pkEntry.ts_nsec.convertToNumber();
            var sec = ns / 1000000000;
            var len = pkEntry.len;
            var textLen = pkEntry.textLen;

            //
            // @TODO: This is not 100% correct.  The string is UTF8 and we need to be able
            //        to read it as a UTF8 string with the proper conversion to a JS string.
            //        There should be a readString variant which takes the encoding.
            //
            var textAddr = entryAddr.add(this.__logInfo.printkLogSize);
            var stext = sec.toFixed(6).padStart(13, ' ');
            var logText = host.memory.readString(textAddr);
            yield "[" + stext + "] " + logText;
            curIdx = curIdx.add(len);
        }
    }
}

// __KernelInformation:
//
// General Linux kernel information.  Projected as 'Kernel' on the session object.
//
class __KernelInformation
{
    constructor(session)
    {
        this.__session = session;
    }

    //*************************************************
    // Properties:
    //

    get PrintKLog()
    {
        return new __KernelLog(this.__session);
    }

    get BlockDevices()
    {
        var blockDevicesList = __getKernelInfo().deviceInfo.blockDevicesList;
        return new __ListTraversal(blockDevicesList, "block_device", "bd_list");
    }

    get CharacterDevices()
    {
        return new __CharacterDevices();
    }

    get FileSystems()
    {
        var superBlocks = __getKernelInfo().fileSystemInfo.superBlockList;
        return new __ListTraversal(superBlocks, "super_block", "s_list");
    }

    get NetworkNamespaces()
    {
        var networkNamespaces = __getKernelInfo().namespaceInfo.netNamespaceList;
        return new __ListTraversal(networkNamespaces, "net", "list");
    }

    get KernFSRoot()
    {
        return __getKernelInfo().kernFsInfo.root;
    }

    get Timers()
    {
        var hrtimerBases = this.GetAllPerCpuInstances(__getKernelInfo().timerInfo.hrtimerBases).value;
        var newTimers = new __NewTimerList(hrtimerBases);

        var timerBases = this.GetAllPerCpuInstances(__getKernelInfo().timerInfo.timerBases).value;
        var oldTimers = new __OldTimerList(timerBases);

        var timers = { OldTimers: oldTimers, NewTimers: newTimers };

        //
        // Metadata for the property must be in the descriptor: PreferredExpansionDepth: 4...
        //
        return timers;
    }

    //*************************************************
    // Methods:
    //

    GetPerCpuInstance(argVar, cpuNum)
    {
        return __getPerCpuInstance(argVar, cpuNum);
    }

    GetAllPerCpuInstances(argVar)
    {
        var perCpuInfo = __getKernelInfo().perCpuInfo;
        var argVarAddr = argVar.address;
        var argVarType = argVar.targetType;

        if (argVarAddr.compareTo(perCpuInfo.perCpuStart) < 0 || argVarAddr.compareTo(perCpuInfo.perCpuEnd) > 0)
        {
            throw new Error("Argument is not a per-cpu variable within the Linux kernel");
        }

        var collection = new __perCpuCollection(argVarAddr, argVarType);
        return new host.metadata.valueWithMetadata(collection, {PreferredExpansionDepth: 2});
    }

    //*************************************************
    // Metadata:
    //

    get [Symbol.metadataDescriptor]()
    {
        return { GetPerCpuInstance: {Help: "GetPerCpuInstance(argVar, [cpuNum]) - Gets a given instance of a per-cpu kernel variable.  If the cpu number is not specified, the current CPU is used"},
                 GetAllPerCpuInstances: {Help: "GetAllPerCpuInstance(argVar) - Gets a collection of every instance of a per-cpu kernel variable" },
                 Timers: {PreferredExpansionDepth: 4} };
    }
}

// __getPerCpuInstance:
//
// Gets a per-cpu instance of a variable for a given cpu.
//
function __getPerCpuInstance(argVar, cpuNum)
{
    var perCpuInfo = __getKernelInfo().perCpuInfo;
    var argVarAddr = argVar.address;
    var argVarType = argVar.targetType;

    if (argVarAddr.compareTo(perCpuInfo.perCpuStart) < 0 || argVarAddr.compareTo(perCpuInfo.perCpuEnd) > 0)
    {
        throw new Error("Argument is not a per-cpu variable within the Linux kernel");
    }

    if (cpuNum === undefined)
    {
        cpuNum = host.currentProcess.KernelObject.cpu;
    }

    if (cpuNum >= perCpuInfo.perCpuOffsetSize)
    {
        throw new RangeError("Unrecognized CPU number");
    }

    var perCpuOffset = perCpuInfo.perCpuOffset[cpuNum];
    if (perCpuOffset.compareTo(0) == 0)
    {
        throw new RangeError("Unrecognized CPU number");
    }

    var perCpuInstance = host.createTypedObject(argVarAddr.add(perCpuOffset), argVarType);
    return perCpuInstance;
}

// __perCpuCollection:
//
// Helper class to return a collection of every instance of a per-cpu variable in the Linux kernel.
//
class __perCpuCollection
{
    constructor(argVarAddr, argVarType)
    {
        this.__argVarAddr = argVarAddr;
        this.__argVarType = argVarType;
    }

    *[Symbol.iterator]()
    {
        var perCpuInfo = __getKernelInfo().perCpuInfo;
        var cpuNum = 0;
        while (cpuNum < perCpuInfo.perCpuOffsetSize)
        {
            var perCpuOffset = perCpuInfo.perCpuOffset[cpuNum];
            if (perCpuOffset.compareTo(0) != 0)
            {
                var perCpuInstance = host.createTypedObject(this.__argVarAddr.add(perCpuOffset), this.__argVarType);
                yield new host.indexedValue(perCpuInstance, [cpuNum]);
            }
            ++cpuNum;
        }
    }

    getDimensionality()
    {
        return 1;
    }

    getValueAt(idx)
    {
        var perCpuInfo = __getKernelInfo().perCpuInfo;
        var perCpuOffset = perCpuInfo.perCpuOffset[idx];
        if (perCpuOffset.compareTo(0) == 0)
        {
            throw new RangeError("Unrecognized CPU number");
        }

        var perCpuInstance = host.createTypedObject(this.__argVarAddr.add(perCpuOffset), this.__argVarType);
        return perCpuInstance;
    }
}



//**************************************************************************
// Visualizers:
//

//*************************************************
// KernFS / SysFS:
//

class __KernFsNodeVisualizer
{
    toString()
    {
        var name = host.memory.readString(this.name);
        var parent = this.parent;
        if (parent.isNull)
        {
            return name;
        }
        else
        {
            return this.parent.dereference().toString() + "/" + name;
        }
    }

    //
    // This is only the right "private data" for a bus. 
    //
    get SubSysPrivate()
    {
        if (this.__isBus())
        {
            var privKObjVoid = this.priv;

            var kernFsInfo = __getKernelInfo().kernFsInfo;
            var addr = privKObjVoid.address.subtract(kernFsInfo.subSysOffset + kernFsInfo.kobjOffset);
            return host.createTypedObject(addr, kernFsInfo.subSysPrivateType);
        }
    }

    get Children()
    {
        var rbNodePtr = this.dir.children.rb_node;
        if (rbNodePtr.isNull)
        {
            return [];
        }

        return new __RbTraversal(rbNodePtr.dereference(), "kernfs_node", "rb");
    }

    // __isBus():
    //
    // Makes a determination of whether this node is a bus and subsqeuently its data is
    // a subsys_private.
    //
    __isBus()
    {
        return (this.__getType() == "bus");
    }

    // __isClass():
    //
    // Make a determination of whether this node is a class and subsequently its data is
    // a <@TODO>.
    //
    __isClass()
    {
        return (this.__getType() == "class");
    }

    // __getType():
    //
    // Returns the type of node.
    //
    __getType()
    {
        //
        // @TODO: There should really be a better way to do this!
        //
        var l1 = this;
        var parent = l1.parent;
        while(!parent.isNull && !l1.isNull)
        {
            var upl = parent.parent;
            if (upl.isNull)
            {
                break;
            }
            l1 = parent;
            parent = l1.parent;
        }
        return host.memory.readString(l1.name);
    }
}

//*************************************************
// Devices:
//

// __DevicePrivateVisualizer:
//
// Visualizer on the kernel "device_private" type.
//
class __DevicePrivateVisualizer
{
    toString()
    {
        // Return the full string from the kernfs path:
        var kernFsPath = this.device.kobj.sd.dereference().toString();
        var driver = this.device.driver;
        if (!driver.isNull)
        {
            var driverName = host.memory.readString(this.device.driver.name);
            return kernFsPath + " (by " + driverName + ")";
        }
        else
        {
            return kernFsPath;
        }
    }
}

// __SubSysPrivateDevices:
//
class __SubSysPrivateDevices
{
    constructor(subSysPrivate)
    {
        this.__subSysPrivate = subSysPrivate;
    }

    *[Symbol.iterator]()
    {
        var klist = this.__subSysPrivate.klist_devices;
        yield* new __KListTraversal(klist, "device_private", "knode_bus");
    }
}

// __SubSysPrivateVisualizer:
//
// Visualizer on the kernel "subsys_private" type.
//
class __SubSysPrivateVisualizer
{
    get Devices()
    {
        return new __SubSysPrivateDevices(this);
    }
}

// __CharacterDevices:
//
// Enumerator for the hash of character devices.
//
class __CharacterDevices
{
    *[Symbol.iterator]()
    {
        var deviceInfo = __getKernelInfo().deviceInfo;
        var characterDevices = deviceInfo.characterDevicesList;
        var count = deviceInfo.characterDevicesCount;

        for (var index = 0; index < count; ++index)
        {
            var devPtr = characterDevices.getValueAt(index);
            if (!devPtr.isNull)
            {
                yield devPtr.dereference();
            }
        }
    }
}

// __CharDeviceStructVisualizer:
//
// Visualizer on the kernel "char_device_struct" type.
//
class __CharDeviceStructVisualizer
{
    toString()
    {
        var name = this.major.toString(10) + " = " + host.memory.readString(this.name);
        return name;
    }
}

// __BlockDeviceVisualizer:
//
// Visualizer on the kernel "block_device" type.
//
class __BlockDeviceVisualizer
{
    toString()
    {
        var deviceInfo = __getKernelInfo().deviceInfo;
        var majorNames = deviceInfo.majorNames;
        var majorNamesCount = deviceInfo.majorNamesCount;
        var majorNumber = this.bd_dev >> 20;
        var index = majorNumber % majorNamesCount;

        var nameInfo = majorNames.getValueAt(index);
        while(index < majorNamesCount)
        {
            if (nameInfo.isNull)
            {
                return majorNumber.toString(10) + " = <unknown>";
            }
            else if (nameInfo.major == majorNumber)
            {
                return majorNumber.toString(10) + " = " + host.memory.readString(nameInfo.name);
            }

            nameInfo = nameInfo.add(1);
            ++index;
        }
    }
}

// __Devices:
//
// Proxy for !dev to combine block & character.
//
class __Devices
{
    get BlockDevices()
    {
        return host.currentSession.Kernel.BlockDevices;
    }

    get CharacterDevices()
    {
        return host.currentSession.Kernel.CharacterDevices;
    }
}

//*************************************************
// Network:
//

// __InIfAddrVisualizer:
//
// Visualizer on the kernel "in_ifaddr" type.
//
class __InIfAddrVisualizer
{
    toString()
    {
        var ip32 = this.ifa_address;
        var str = "";
        str += (ip32 & 0xFF).toString() + "." +
               ((ip32 >> 8) & 0xFF).toString() + "." +
               ((ip32 >> 16) & 0xFF).toString() + "." +
               ((ip32 >> 24) & 0xFF);

        return str;
    }
}

// __NetDeviceIPv4AddressList
//
// Enumerates all IPv4 addresses on a net_device
//
class __NetDeviceIPv4AddressList
{
    constructor(netDevice)
    {
        this.__netDevice = netDevice;
    }

    *[Symbol.iterator]()
    {
        var in_device = this.__netDevice.ip_ptr.dereference();
        var ifa = in_device.ifa_list;
        while(!ifa.isNull)
        {
            yield ifa.dereference();
            ifa = ifa.ifa_next;
        }
    }
}

// __NetDeviceVisualizer:
//
// Visualizer on the kernel "net_device" type.
//
class __NetDeviceVisualizer
{
    toString()
    {
        // @TODO: UTF8:
        var devName = host.memory.readString(this.name.address, this);

        var ipv4 = null;
        for (var in_ifaddr of this.IPv4Addresses)
        {
            ipv4 = in_ifaddr.toString();
            break;
        }

        if (ipv4)
        {
            return devName + " (" + ipv4 + ")";
        }
        
        return devName;
    }

    get IPv4Addresses()
    {
        return new __NetDeviceIPv4AddressList(this);
    }
}

// __NetVisualizer:
//
// Visualizer on the kernel "net" type.
//
class __NetVisualizer
{
    get Devices()
    {
        return new __ListTraversal(this.dev_base_head, "net_device", "dev_list"); 
    }
}

//*************************************************
// File System:
//

// __DEntryVisualizer:
//
// Visualizer on the kernel "dentry" type.
//
class __DEntryVisualizer
{
    toString()
    {
        // @TODO: UTF8...
        var localName = host.memory.readString(this.d_name.name.address, this);
        var parent = this.d_parent.dereference();
        if (this.address.compareTo(parent.address) != 0)
        {
            return __pathCombine(parent.toString(), localName);
        }
        else
        {
            return localName;
        }
    }
}

// __PathVisualizer:
//
// Visualizer on the kernel "path" type.
//
class __PathVisualizer
{
    toString()
    {
        var mountPath = this.Mount.Path;
        return __pathCombine(mountPath, this.dentry.dereference().toString());
    }

    get Mount()
    {
        var mountTy = host.getModuleType("vmlinux", "mount");
        var mntFld = mountTy.fields.mnt;
        var mntOffset = mntFld.offset;
        return host.createTypedObject(this.mnt.address.subtract(mntOffset), mountTy);
    }
}

// __FileVisualizer:
//
// Visualizer on the kernel "file" type.
//
class __FileVisualizer
{
    toString()
    {
        return this.f_path.toString();
    }
}

// __MntNamespaceVisualizer:
//
// Visualizer on the kernel "mnt_namespace" type.
//
class __MntNamespaceVisualizer
{
    get Mounts()
    {
        return new __ListTraversal(this.list, "mount", "mnt_list");
    }
}

// __MountVisualizer:
//
// Visualizer on the kernel "mount" type.
//
class __MountVisualizer
{
    toString()
    {
        var mountPoint = this.mnt_mountpoint.dereference().toString();
        var superBlock = this.mnt.mnt_sb;
        
        // @TODO: UTF8
        var sbTypeName = host.memory.readString(superBlock.s_type.name.address, superBlock);

        // @TODO: UTF8
        var deviceName = host.memory.readString(this.mnt_devname.address, this);
        return "(" + sbTypeName + ") " + deviceName + " at " + mountPoint;
    }

    get Path()
    {
        return this.mnt_mountpoint.dereference().toString();
    }
}

// __SuperBlockVisualizer:
//
// Visualizer on the kernel "super_block" type.
//
class __SuperBlockVisualizer
{
    toString()
    {
        // @TODO: UTF8
        var sbTypeName = host.memory.readString(this.s_type.name.address, this);
        return sbTypeName;
    }

    get Mounts()
    {
        return new __ListTraversal(this.s_mounts, "mount", "mnt_instance");
    }
}

// __QStrVisualizer:
//
// Visualizer on the kernel "qstr" type.
//
class __QStrVisualizer
{
    toString()
    {
        return host.memory.readString(this.name.address, this.len);
    }
}

// __KernelProcessFiles:
//
// List of files within a process.  Attempts to mirror 'files' functionality of the Linux
// crash tool.
//
class __KernelProcessFiles
{
    constructor(task)
    {
        this.__task = task;
    }

    toString()
    {
        // @TODO: UTF8
        var taskName = host.memory.readString(this.__task.comm.address, this.__task);
        var str = "Files for process '" + taskName + "' (pid " + this.__task.pid.toString() + ")";
        var fsRoot = this.__task.fs.root.toString();
        var wdir = this.__task.fs.pwd.toString();
        str += " root dir = '" + fsRoot + "' working dir = '" + wdir + "'";
        return str;
    }

    getDimensionality()
    {
        return 1;
    }

    getValueAt(idx)
    {
        var files = this.__task.files.dereference();
        var fdt = files.fdt.dereference();
        var ct = fdt.max_fds;
        var ppfd = fdt.fd;
        if (idx >= ct)
        {
            throw new RangeError("Invalid file descriptor");
        }
        if (idx > 0)
        {
            ppfd = ppfd.add(idx);
        }
        var pfd = ppfd.dereference();
        if (pfd.isNull)
        {
            throw new RangeError("Invalid file descriptor");
        }
        return pfd.dereference();
    }

    *[Symbol.iterator]()
    {
        var files = this.__task.files.dereference();
        var fdt = files.fdt.dereference();
        var ct = fdt.max_fds;
        var ppfd = fdt.fd;
        for(var i = 0; i < ct; ++i)
        {
            var pfd = ppfd.dereference();
            if (!pfd.isNull)
            {
                yield new host.indexedValue(pfd.dereference(), [i]);
            }

            ppfd = ppfd.add(1);
        }
    }
}

//*************************************************
// Memory:
//

var __vmFlags =
[
    "VM_READ",              // 0x00000001
    "VM_WRITE",             // 0x00000002
    "VM_EXEC",              // 0x00000004
    "VM_SHARED",            // 0x00000008
    "VM_MAYREAD",           // 0x00000010
    "VM_MAYWRITE",          // 0x00000020
    "VM_MAYEXEC",           // 0x00000040
    "VM_MAYSHARE",          // 0x00000080
    "VM_GROWSDOWN",         // 0x00000100
    "VM_UFFD_MISSING",      // 0x00000200
    "VM_PFNMAP",            // 0x00000400
    "VM_DENYWRITE",         // 0x00000800
    "VM_UFFD_WP",           // 0x00001000
    "VM_LOCKED",            // 0x00002000
    "VM_IO",                // 0x00004000
    "VM_SEQ_READ",          // 0x00008000
    "VM_RAND_READ",         // 0x00010000
    "VM_DONTCOPY",          // 0x00020000
    "VM_DONTEXPAND",        // 0x00040000
    "VM_LOCKONFAULT",       // 0x00080000
    "VM_ACCOUNT",           // 0x00100000
    "VM_NORESERVE",         // 0x00200000
    "VM_HUGETLB",           // 0x00400000
    "VM_SYNC",              // 0x00800000
    "VM_ARCH_1",            // 0x01000000
    "VM_WIPEONFORK",        // 0x02000000
    "VM_DONTDUMP",          // 0x04000000
    "VM_SOFTDIRTY",         // 0x08000000
    "VM_MIXEDMAP",          // 0x10000000
    "VM_HUGEPAGE",          // 0x20000000
    "VM_NOHUGEPAGE",        // 0x40000000
    "VM_MERGEABLE"          // 0x80000000
];

// __VmAreaStructVisualizer:
//
// Visualizer on the "vm_area_struct" type.
//
class __VmAreaStructVisualizer
{
    toString()
    {
        var desc = "[" + this.vm_start.toString(16) + " - " + this.vm_end.toString(16) + ")";
        if (!this.vm_file.isNull)
        {
            desc += " = " + this.vm_file.dereference().toString();
        }
        return desc;
    }

    get Flags()
    {
        var flagsVal = { };
        var fdesc = "";
        var hasBit = false;

        var bitVal = new host.Int64(1);
        var flags = this.vm_flags;
        for (var i = 0; i < __vmFlags.length; ++i)
        {
            if (flags.bitwiseAnd(bitVal).compareTo(0) != 0)
            {
                flagsVal[__vmFlags[i]] = true;
                if (hasBit)
                {
                    fdesc += " | ";
                }
                fdesc += __vmFlags[i];
                hasBit = true;
            }
            else
            {
                flagsVal[__vmFlags[i]] = false;
            }
            bitVal = bitVal.bitwiseShiftLeft(1);
        }
        flagsVal.toString = function() { return fdesc; };
        return flagsVal;
    }
}

// __VMAreaList:
//
// Presents as a list of vm_area_structs by walking the va_next links
//
class __VmAreaList
{
    constructor(startVaPtr)
    {
        this.__startVaPtr = startVaPtr;
    }

    *[Symbol.iterator]()
    {
        var ptr = this.__startVaPtr;
        while(!ptr.isNull)
        {
            var vaStruct = ptr.dereference();
            yield vaStruct;
            ptr = vaStruct.vm_next;
        }
    }
}

//*************************************************
// Timers:
//

// __CpuOldTimerList:
//
// Presents the timer_base[] for a CPU as a collection of timer_base structures.
//
class __CpuOldTimerList
{
    constructor(timerBaseArray, cpuNum)
    {
        this.__timerBaseArray = timerBaseArray;
        this.__cpuNum = cpuNum;
    }

    toString()
    {
        return "CPU " + this.__cpuNum.toString();
    }

    *[Symbol.iterator]()
    {
        var id = 0;
        for (var timerBase of this.__timerBaseArray)
        {
            yield new __TimerBaseProjectLists(timerBase, id);
            ++id;
        }
    }
}

// __TimerBaseProjectLists:
//
// Just a projection of .TimerLists on a timer_base.
//
class __TimerBaseProjectLists
{
    constructor(timerBase, id)
    {
        this.__timerBase = timerBase;
        this.__id = id;
    }

    toString()
    {
        if (this.__id == 0)
        {
            return "BASE_STD";
        }
        else if (this.__id == 1)
        {
            return "BASE_DEF";
        }
    }

    *[Symbol.iterator]()
    {
        yield* this.__timerBase.TimerLists;
    }
}

//
// __TimerBaseTimerList
//
// Helper for filtering out relevant timer lists from a timer base (the list items)
//
class __TimerBaseTimerList
{
    constructor(timerBase, hentry)
    {
        this.__timerBase = timerBase;
        this.__hentry = hentry;
    }

    *[Symbol.iterator]()
    {
        var timerInfo = __getKernelInfo().timerInfo;
        var hentry = this.__hentry;

        while (!hentry.isNull)
        {
            var timerList = host.createTypedObject(hentry.address.subtract(timerInfo.entryOffset), 
                                                   timerInfo.timerListType);
            yield timerList;

            hentry = hentry.next;
        }
    }
}

// __TimerBaseTimerLists
//
// Helper for filtering out relevant timer lists from a timer base (the hash buckets)
//
class __TimerBaseTimerLists
{
    constructor(timerBase)
    {
        this.__timerBase = timerBase;
    }

    *[Symbol.iterator]()
    {
        //
        // There's a series of hash buckets in vec which each contain lists of timer_list structures.
        //
        var timerInfo = __getKernelInfo().timerInfo;
        for (var vec of this.__timerBase.vectors)
        {
            var first = vec.first;
            if (!first.isNull)
            {
                yield* new __TimerBaseTimerList(this.__timerBase, first);
            }
        }
    }
}

// __TimerBaseVisualizer:
//
// Visualizer on the kernel timer_base type.
//
class __TimerBaseVisualizer
{
    get TimerLists()
    {
        return new __TimerBaseTimerLists(this);
    }
}

// __TimerListVisualizer:
//
// Visualizer on the kernel timer_list type.
//
class __TimerListVisualizer
{
    toString()
    {
        var expiry = this.expires;
        var func = this.function.dereference();
        var funcName = func.name;
        var tte = this.TimeUntilExpiration;
        return "Expiration = " + expiry + " (TTE = " + tte.toString(10) + ") , Function = " + func.address.toString(16) + " <" + funcName + ">";
    }

    get TimeUntilExpiration()
    {
        return this.expires.subtract(__getKernelInfo().timerInfo.jiffies);
    }
}

// __OldTimerList:
//
// Presents a list of timers from a collection of all per-cpu timer_base structures.
//
class __OldTimerList
{
    constructor(timerBasesArrays)
    {
        this.__timerBasesArrays = timerBasesArrays;
    }

    *[Symbol.iterator]()
    {
        var cpu = 0;
        for (var timerBaseArray of this.__timerBasesArrays)
        {
            yield new __CpuOldTimerList(timerBaseArray.value, cpu);
            ++cpu;
        }
    }
}

// __HrTimerVisualizer:
//
// Visualizer on the kernel hrtimer type.
//
class __HrTimerVisualizer
{
    toString()
    {
        var softExpiry = this._softexpires;
        var func = this.function.dereference();
        var funcName = func.name;
        return "Soft Expiration = " + softExpiry + ", Function = " + func.address.toString(16) + " <" + funcName + ">";
    }
}

// __HrTimerList:
//
// Presents as a list of hrtimers from a clock base by an RB traversal and cast.
//
class __HrTimerList
{
    constructor(clockBase)
    {
        this.__clockBase = clockBase;
    }

    *[Symbol.iterator]()
    {
        var timerInfo = __getKernelInfo().timerInfo;
        var rbNode = this.__clockBase.active.head.rb_node;
        if (!rbNode.isNull)
        {
            var nodeAddr = rbNode.address;
            yield host.createTypedObject(nodeAddr.subtract(timerInfo.nodeOffset), timerInfo.hrtimerType);
            
            var nodes = new __RbTraversal(rbNode, "timerqueue_node", "node");
            for (var node of nodes)
            {
                nodeAddr = node.address;
                yield host.createTypedObject(nodeAddr.subtract(timerInfo.nodeOffset), timerInfo.hrtimerType);
            }
        }
    }
}

// __HrTimerClockBaseVisualizer:
//
// Visualizer for the kernel hrtimer_clock_base structure
//
class __HrTimerClockBaseVisualizer
{
    toString()
    {
        var func = this.get_time.dereference();
        var funcName = func.name;
        return "[" + funcName + "]";
    }

    get Timers()
    {
        return new __HrTimerList(this);
    }
}

class __ClockBaseTimers
{
    constructor(clockBase, num)
    {
        this.__clockBase = clockBase;
        this.__num = num;
    }

    toString()
    {
        return "CLOCK " + this.__num.toString() + " " + this.__clockBase.toString();
    }

    *[Symbol.iterator]()
    {
        for(var timer of this.__clockBase.Timers)
        {
            yield timer;
        }
    }
}

// __CpuTimerList:
//
// Presents an hrtimer_clock_base as a list of clock bases / timers.
//
class __CpuTimerList
{
    constructor(cpuBase, cpuNum)
    {
        this.__cpuBase = cpuBase;
        this.__cpuNum = cpuNum;
    }

    toString()
    {
        return "CPU " + this.__cpuNum.toString();
    }

    *[Symbol.iterator]()
    {
        var clockNum = 0;
        for (var clockBase of this.__cpuBase.clock_base)
        {
            yield new __ClockBaseTimers(clockBase, clockNum);
            ++clockNum;
        }
    }
}

// __NewTimerList:
//
// Presents a list of timers/clock bases from a collection of all per-cpu hrtimer_cpu_base structures.
//
class __NewTimerList
{
    constructor(cpuBases)
    {
        this.__cpuBases = cpuBases;
    }

    *[Symbol.iterator]()
    {
        var cpu = 0;
        for (var cpuBase of this.__cpuBases)
        {
            yield new __CpuTimerList(cpuBase.value, cpu);
            ++cpu;
        }
    }
}

//*************************************************
// __ProcessMemoryExtension:
//
// Extensions placed on a per-process basis
//

class __ProcessMemoryExtension
{
    get VirtualMemoryAreas()
    {
        return new __VmAreaList(this.KernelObject.mm.mmap);
    }
}

//*************************************************
// __ProcessIoExtension:
//
// Extensions placed on a per-process basis
//

class __ProcessIoExtension
{
    get [Symbol.metadataDescriptor]()
    {
        return { Files: { Help: "The list of open files in the process context" } };
    }

    get RootDirectory()
    {
        return this.KernelObject.fs.root;
    }

    get WorkingDirectory()
    {
        return this.KernelObject.fs.pwd;
    }

    get Files()
    {
        return new __KernelProcessFiles(this.KernelObject);
    }

    get MountNamespace()
    {
        return this.KernelObject.nsproxy.mnt_ns.dereference();
    }

    get NetworkNamespace()
    {
        return this.KernelObject.nsproxy.net_ns.dereference();
    }
}

//*************************************************
// __SessionExtension:
//
// Extensions placed on a per-session basis
//

class __SessionExtension
{
    get Kernel()
    {
        return new __KernelInformation(this);
    }
}

//**************************************************************************
// Commands:
//
// These are designed to *somewhat* mirror the commands that present from a Linux crash session.
// Given the architecture is different here, they do not take the same arguments and the like, but their
// *bare* function and simple argument function is similar.
//

// __getTaskFromCommandArgument:
//
// Attempts to get the task_struct associated with a given command argument.   The command argument can
// be in one of several forms:
//
// pid               - Gets the task for the given pid
// 64-bit num        - Gets the task for the task_struct at the given address
// <task struct [*]> - Gets the task_struct for the given object
// <process object>  - Gets the task_struct for the given process
//
// If such cannot be found, null is returned.
//
function __getTaskFromCommandArgument(arg)
{
    var addr = 0;
    if (typeof(arg) == 'number')
    {
        try
        {
            var proc = host.currentSession.Processes.getValueAt(arg);
            return proc.KernelObject;
        }
        catch(exc)
        {
        }

        //
        // It could be an address that wasn't assumed/converted to 64-bit.
        //
        if (arg >= 0x10000)
        {
            var taskStruct = host.createTypedObject(arg, "vmlinux", "task_struct");
            return taskStruct;
        }
    }

    if (arg.asNumber !== undefined)
    {
        //
        // It's not a task_struct pointer with a very low address that looks more like a 
        // PID.
        //
        if (arg.compareTo(0x10000) >= 0)
        {
            var taskStruct = host.createTypedObject(arg, "vmlinux", "task_struct");
            return new __KernelProcessFiles(taskStruct);
        }
    }
    else if (arg.targetType !== undefined)
    {
        var ty = arg.targetType;
        if (ty.typeKind == "pointer")
        {
            arg = arg.dereference();
            ty = arg.targetType;
        }

        if (ty.name == "task_struct")
        {
            return arg;
        }
    }
    else if (arg.KernelObject !== undefined)
    {
        var potentialTask = arg.KernelObject;
        var ty = potentialTask.targetType;
        if (ty.name == "task_struct")
        {
            return potentialTask;
        }
    }

    return null;
}

// __files:
//
// Present as a legacy !files command similar to the crash files command:
//
// !files [<arg>]
//
//     Without [<arg>]             - Equivalent to 'files' -- gives current process file list
//     [<arg>] - pid               - Gives the file list for the given process id
//             - 64-bit num        - Gives the file list for the task at the given address
//             - <task struct [*]> - Gives the file list for the given task struct by object
//             - <process object>  - Gives the file list for the task represented by the process object
//
function __files(arg)
{
    if (arg === undefined)
    {
        return host.currentProcess.Io.Files;
    }

    var taskStruct = __getTaskFromCommandArgument(arg);
    if (taskStruct)
    {
        return new __KernelProcessFiles(taskStruct);
    }

    throw new Error("Illegal argument to files function");
}

// __net:
//
// Present as a legacy !net command similar to the crash net command:
//
// !net [<arg>]
//
//     Without [<arg>]             - Equivalent to 'net' -- gives system network list
//     [<arg>] - pid               - Gives the net list for namespace of the process with the given pid
//             - 64-bit num        - Gives the net list for the namespace of the task_struct given by address
//             - <task struct [*]> - Gives the net list for the namespace of the given task_struct
//             - <process object>  - Gives the net list for the namespace of the task represented by the process object
//
function __net(arg)
{
    if (arg === undefined)
    {
        //
        // PID == 0 is the swapper (system process).  Find its network namespace and dump the device list.
        //
        return host.currentSession.Processes.getValueAt(0).Io.NetworkNamespace.Devices;
    }

    var taskStruct = __getTaskFromCommandArgument(arg);
    if (taskStruct)
    {
        return taskStruct.nsproxy.net_ns.Devices;
    }

    throw new Error("Illegal argument to net function");
}

// __mount:
//
// Present as a legacy !mount command similar to the crash mount command:
//
// !mount [<arg>]
//
//     Without [<arg>]             - Equivalent to 'net' -- gives system network list
//     [<arg>] - pid               - Gives the net list for namespace of the process with the given pid
//             - 64-bit num        - Gives the net list for the namespace of the task_struct given by address
//             - <task struct [*]> - Gives the net list for the namespace of the given task_struct
//             - <process object>  - Gives the net list for the namespace of the task represented by the process object
//
function __mount(arg)
{
    if (arg === undefined)
    {
        //
        // PID == 0 is the swapper (system process).  Find its network namespace and dump the device list.
        //
        return host.currentSession.Processes.getValueAt(0).Io.MountNamespace.Mounts;
    }

    var taskStruct = __getTaskFromCommandArgument(arg);
    if (taskStruct)
    {
        return taskStruct.nsproxy.mnt_ns.Mounts;
    }

    throw new Error("Illegal argument to mount function");
}

// __vm:
//
// Present as a legacy !vm command similar to the crash vm command:
//
// !vm [<arg>]
//
//     Without [<arg>]             - Equivalent to 'vm' -- gives the vm layout for the current process
//
function __vm(arg)
{
    if (arg === undefined)
    {
        return host.currentProcess.Memory.VirtualMemoryAreas;
    }

    var taskStruct = __getTaskFromCommandArgument(arg);
    if (taskStruct)
    {
        return new __VmAreaList(taskStruct.mm.mmap);
    }

    throw new Error("Illegal argument to vm function");
}

// __log:
//
// Present as a legacy !log command similar to the crash log command:
//
// !log
//
function __log()
{
    return host.currentSession.Kernel.PrintKLog;
}

// __dev:
//
// Present as a legacy !dev command similar to the crash dev command:
//
// !dev
//
function __dev()
{
    return new host.metadata.valueWithMetadata(new __Devices(), {PreferredExpansionDepth: 2});
}

// __percpu:
//
// Present as a legacy !percpu command to display per-cpu variables:
//
// !percpu var, [cpu]
//
function __percpu(argVar, cpuNum)
{
    return __getPerCpuInstance(argVar, cpuNum);
}

// __allpercpu:
//
// Present as a legacy !allpercpu command to return a collection of every instance of a per-cpu variable:
//
function __allpercpu(argVar)
{
    var perCpuInfo = __getKernelInfo().perCpuInfo;
    var argVarAddr = argVar.address;
    var argVarType = argVar.targetType;

    if (argVarAddr.compareTo(perCpuInfo.perCpuStart) < 0 || argVarAddr.compareTo(perCpuInfo.perCpuEnd) > 0)
    {
        throw new Error("Argument is not a per-cpu variable within the Linux kernel");
    }

    var collection = new __perCpuCollection(argVarAddr, argVarType);
    return new host.metadata.valueWithMetadata(collection, {PreferredExpansionDepth: 2});
}

// __timer:
//
// Present a legacy !timer command similar to the crash timer command.
//
function __timer()
{
    return new host.metadata.valueWithMetadata(host.currentSession.Kernel.Timers, { PreferredExpansionDepth: 4} );
}

//**************************************************************************
// Script Initialization:
//

// initializeScript:
//
// Initializes our script.  Registers our extensions and various crash like "commands".
//
function initializeScript()
{
    return [new host.apiVersionSupport(1, 5),
            
            //*************************************************
            // Extension Records:
            //
            new host.namedModelParent(__SessionExtension, "Debugger.Models.Session"),
            new host.namespacePropertyParent(__ProcessIoExtension, "Debugger.Models.Process", "Debugger.Models.Process.Io", "Io"),
            new host.namespacePropertyParent(__ProcessMemoryExtension, "Debugger.Models.Process", "Debugger.Models.Process.Memory", "Memory"),

            //*************************************************
            // Visualizer Records (File System):
            //
            new host.typeSignatureExtension(__FileVisualizer, "file", "vmlinux"),
            new host.typeSignatureExtension(__PathVisualizer, "path", "vmlinux"),
            new host.typeSignatureExtension(__DEntryVisualizer, "dentry", "vmlinux"),
            new host.typeSignatureExtension(__SuperBlockVisualizer, "super_block", "vmlinux"),
            new host.typeSignatureExtension(__MountVisualizer, "mount", "vmlinux"),
            new host.typeSignatureExtension(__MntNamespaceVisualizer, "mnt_namespace"),
            new host.typeSignatureRegistration(__QStrVisualizer, "qstr", "vmlinux"),

            //*************************************************
            // Visualizer Records (Network:)
            //
            new host.typeSignatureExtension(__NetVisualizer, "net", "vmlinux"),
            new host.typeSignatureExtension(__NetDeviceVisualizer, "net_device", "vmlinux"),
            new host.typeSignatureExtension(__InIfAddrVisualizer, "in_ifaddr", "vmlinux"),

            //*************************************************
            // Visualizer Records (Memory:)
            //
            new host.typeSignatureExtension(__VmAreaStructVisualizer, "vm_area_struct", "vmlinux"),

            //*************************************************
            // Visualizer Records (Devices:)
            //
            new host.typeSignatureExtension(__BlockDeviceVisualizer, "block_device", "vmlinux"),
            new host.typeSignatureExtension(__CharDeviceStructVisualizer, "char_device_struct", "vmlinux"),
            new host.typeSignatureExtension(__DevicePrivateVisualizer, "device_private", "vmlinux"),

            //*************************************************
            // Visualizer Records (KernFS):
            //
            new host.typeSignatureExtension(__KernFsNodeVisualizer, "kernfs_node", "vmlinux"),
            new host.typeSignatureExtension(__SubSysPrivateVisualizer, "subsys_private", "vmlinux"),

            //*************************************************
            // Visualizer Records (Timers:)
            //
            new host.typeSignatureExtension(__HrTimerClockBaseVisualizer, "hrtimer_clock_base", "vmlinux"),
            new host.typeSignatureExtension(__HrTimerVisualizer, "hrtimer", "vmlinux"),
            new host.typeSignatureExtension(__TimerBaseVisualizer, "timer_base", "vmlinux"),
            new host.typeSignatureExtension(__TimerListVisualizer, "timer_list", "vmlinux"),

            //*************************************************
            // Function Alias (Command) Records:
            //
            new host.functionAlias(__files, "files"),
            new host.functionAlias(__mount, "mount"),
            new host.functionAlias(__net, "net"),
            new host.functionAlias(__vm, "vm"),
            new host.functionAlias(__log, "log"),
            new host.functionAlias(__dev, "dev"),
            new host.functionAlias(__percpu, "percpu"),
            new host.functionAlias(__allpercpu, "allpercpu"),
            new host.functionAlias(__percpu, "lx_per_cpu"),
            new host.functionAlias(__timer, "timer"),

            ];
}
